# 第0篇配图 Prompt 记录（v3/v4）

> 五张图均按「Lee概念隐喻配图」技能模板生成。
> 统一参数：`ref_images=["/app/data/所有对话/主对话/assets/avatar/ai-avatar-flat.png"]`、`mode="生图"`、`size="2k"`、`from_image_gen_skill=true`。
> 统一画幅：3:4 竖版。
> P3（零依赖）为 v4 重出版，prompt 为原文；其余四张按生成时的画面要素忠实复现，结构完全一致。

---

## 共用 Visual DNA（每张开头相同）

```
Generate one standalone 3:4 vertical Chinese concept illustration.

Visual DNA:
Deep black solid background. Flat vector illustration style, minimal geometric elements. White thin lines for structure outlines, clean and crisp, no hand-drawn wobble. Brand orange as the only accent color, used sparingly for key arrows, annotations, and emphasis symbols. Plenty of empty black space (subject occupies 40-60%). No gradients, no shadows, no textures, no 3D effects, no commercial poster style, no PPT grid/chart look, no cute mascot, no UI screenshots.

Character required:
Lee, use the reference image character, keep appearance unchanged. Lee must be the core action subject—demonstrating, operating, or explaining the concept. His expression should be focused and engaged, not overly emotional.
```

---

## P1 封面 — 装 Skill（配图v3-01-装skill.jpg）

结构类型：Conceptual Metaphor

```
Theme:
给AI Agent装上文献检索Skill——像给机器人装入一颗能力芯片

Core idea:
Skill 就是一颗即插即用的能力芯片，装进去 Agent 就获得文献检索能力。

Scene:
Lee stands at center, both hands carefully lifting a glowing orange microchip upward, inserting it into the open top slot of a simple white-outlined AI robot head floating in front of him. The robot head is minimal geometric—square face, two dot eyes, thin line contours. Small orange emphasis marks radiate from the chip-slot contact point, showing the moment of activation. Lee's posture is focused, arms raised.

Key elements:
Lee lifting chip with both hands / glowing orange chip / white-outlined robot head with open slot / small orange activation sparks

Labels: none — absolutely no text anywhere in the image

Color rules:
Deep black background. White for structure lines and Lee. Brand orange ONLY for the chip and activation emphasis marks. No other colors.
```

---

## P2 四数据库（配图v3-02-四数据库.jpg）

结构类型：System Detail

```
Theme:
一条命令同时检索四大免费学术数据库

Core idea:
一个入口，四个数据库并行被激活，结果向中心汇聚。

Scene:
Lee stands at center with both arms spread wide open, palms facing outward, simultaneously activating four distinct geometric database icons arranged in an arc around him—each a different minimal white-outlined shape (cylinder, cube, stacked discs, document stack). Four thin white lines connect Lee's hands to each database, and each database sends a thin flow line converging toward a single point below Lee, symbolizing unified results. One or two key flow lines highlighted in brand orange.

Key elements:
Lee arms spread activating / four distinct geometric database icons / thin connecting lines / converging flow lines with orange highlights

Labels: none — absolutely no text anywhere in the image

Color rules:
Deep black background. White for structure lines, Lee, and databases. Brand orange ONLY for one or two key flow lines. No other colors.
```

---

## P3 零依赖（配图v4-03-零依赖.jpg）✅ 原文

结构类型：Conceptual Metaphor

```
Theme:
零依赖——安装即用，不需要任何额外配置

Core idea:
传统方案要拖一堆沉重依赖（API key、环境配置、命令行工具），这个Skill一个文件就是全部所需，轻装上阵。

Scene:
Lee walks forward lightly and confidently toward the right, one hand casually holding a single small glowing orange cube (the skill, all you need) at chest height. Behind him on the left, a large heavy white-outlined toolbox overflows with tangled gears, chains and cables; the toolbox and its contents are dissolving into fading broken thin lines drifting away, symbolizing discarded dependencies. A subtle thin white arrow points from the dissolving toolbox toward Lee's orange cube. Lee's stride is relaxed, one foot forward, body slightly leaning into motion.

Key elements:
Lee walking lightly / single glowing orange cube in hand / heavy dissolving toolbox with gears and cables fading into broken lines / one thin arrow

Labels: none — absolutely no text anywhere in the image

Color rules:
Deep black background. White for structure lines and Lee character. Brand orange ONLY for the small cube's glow and one emphasis arrow. No other colors.
```

---

## P4 底座引擎（配图v3-04-底座引擎.jpg）

结构类型：Method Layers

```
Theme:
这是论文写作Skills系列的底座——后续所有Skill都长在这上面

Core idea:
底座先行，上层模块陆续叠加，整个系列是一个生长结构。

Scene:
Lee kneels or crouches slightly at lower center, both hands placing a wide, solid glowing orange platform (the foundation/base) firmly onto the ground line. Above the platform, two or three empty white-outlined module frames float in a vertical stack, slightly offset, with thin dashed lines connecting them down to the base—waiting to be stacked. A small orange arrow points upward from the base toward the floating modules, showing growth direction. Lee looks up at the modules while securing the base.

Key elements:
Lee placing glowing orange base platform / floating empty white module frames above / dashed connection lines / upward orange arrow

Labels: none — absolutely no text anywhere in the image

Color rules:
Deep black background. White for structure lines, Lee, and module frames. Brand orange ONLY for the base platform and growth arrow. No other colors.
```

---

## P5 主页自取（配图v3-05-主页自取.jpg）

结构类型：Conceptual Metaphor

```
Theme:
Skill文件已就绪，来主页拿走

Core idea:
成品打包好了，直接递到读者手上——降低获取门槛的行动号召。

Scene:
Lee stands slightly right of center, body turned toward the viewer, extending one arm forward to hand a neatly packaged glowing orange parcel (the Skill file, tied with a thin string bow) directly toward the viewer, breaking the fourth wall. His other hand gestures openly as if saying "take it". Behind him on the left, a simple white-outlined house/profile icon floats subtly, marking "homepage". Lee's expression is warm and confident, slight smile.

Key elements:
Lee extending orange parcel toward viewer / thin string bow on parcel / subtle house icon in background / open welcoming gesture

Labels: none — absolutely no text anywhere in the image

Color rules:
Deep black background. White for structure lines, Lee, and background icon. Brand orange ONLY for the parcel. No other colors.
```

---

## 共用结尾 Constraints（每张末尾相同）

```
Constraints:
One image explains only one core structure. Main subject 40-60% of canvas. Minimal elements. No text, no letters, no numbers, no labels anywhere. Do not write a title. Do not make it a formal diagram or course slide. Do not copy prior examples. Invent a fresh visual metaphor. Clean, minimal, instantly understandable. 3:4 vertical ratio.
```
